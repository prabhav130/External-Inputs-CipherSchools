// #include<iostream>
#include<bits/stdc++.h>

using namespace std;

// int sum(int a,int b);

int sum(int a ,int b= 0){
  return a+b;
}

int main(){

  cout<<sum(2);

  return 0;
}

//  int sum(int a,int b){
//   return a+b;
// }