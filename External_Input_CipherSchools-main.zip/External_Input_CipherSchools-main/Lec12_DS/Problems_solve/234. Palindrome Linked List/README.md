[View Problem](https://leetcode.com/problems/palindrome-linked-list)
