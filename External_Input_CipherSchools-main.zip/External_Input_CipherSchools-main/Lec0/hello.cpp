// #include<iostream>
#include<bits/stdc++.h>

using namespace std;

int main(){

  cout<<"Hello world.!";
  // std::cout<<"Hello world.!";

  return 0;
}