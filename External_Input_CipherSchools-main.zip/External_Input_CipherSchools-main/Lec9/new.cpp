// #include<iostream>
#include<bits/stdc++.h>

using namespace std;

int main(){
    // int a = 10;

    // int arr[5];
    int n;
    cin>>n;

    int*arr = new int[5];

    arr[0]= 101;

    // int* a = new int;


    // int*arr = new int[5];
    // int* b = (int*)malloc(sizeof(int)*5);
    delete[] arr;
    // arr = NULL;

    int*ptr =NULL;
    // int* ptri = new int(10);
    // cout<<*ptri<<endl;
    // *ptri = 10;
    // delete ptri;
    // free(ptri);
  return 0;
}