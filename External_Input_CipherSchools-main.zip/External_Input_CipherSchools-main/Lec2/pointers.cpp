// #include<iostream>
#include<bits/stdc++.h>

using namespace std;

int main(){

  // int a = 10;
  // int*p = &a;

  // char ch = 'a';
  // char* pch = &ch;

  // int b = 10;
  // int&a = b;

  // cout<<a<<endl;

  // int* c = &b;

  // if(sizeof(pch) == sizeof(p)){
  //   cout<<"hey"<<endl;
  // }else{
  //   cout<<"hii"<<endl;
  // }

  // cout<<*(&a)<<endl;
  // cout<<*p<<endl;
  // cout<<sizeof(p)<<endl;
  return 0;
}