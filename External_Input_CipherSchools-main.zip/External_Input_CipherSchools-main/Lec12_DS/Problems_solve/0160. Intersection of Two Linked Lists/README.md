[View Problem](https://leetcode.com/problems/intersection-of-two-linked-lists)
