// #include<iostream>
#include<bits/stdc++.h>

using namespace std;

void display(int arr[],int s){
  for(int i =0;i<s;i++)cout<<arr[i];
  cout<<endl;
}

int main(){

  int arr[] = {1,2,3,4,5};

  // display(arr,5);
  cout<<arr[3]<<endl;

  // for(int i = 0;i<5;i++)cin>>arr[i];

  return 0;
}