[View Problem](https://leetcode.com/problems/rotate-list)
